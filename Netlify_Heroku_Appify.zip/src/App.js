import React, { lazy } from 'react'
import { BrowserRouter as Router, Switch, Route, Redirect } from 'react-router-dom'

const Layout = lazy(() => import('./containers/Layout'))
const StockDetails = lazy(() => import('./pages/StockDetails'))

function App() {
  return (
    <>
      <Router>
        <Switch>
          <Route path="/app" component={Layout} />
          <Route path="/stockDetails" component={StockDetails} />
          <Redirect exact from="/" to="/app/dashboard" />
        </Switch>
      </Router>
    </>
  )
}

export default App
