import React, { useContext } from 'react'
import { SidebarContext } from '../context/SidebarContext'
import Logo from '../assets/img/logo.png'
import {
  MenuIcon,
} from '../icons'

function Header() {
  const { toggleSidebar } = useContext(SidebarContext)

 

  return (
    <header className="z-40 py-4 bg-blue-900 shadow-bottom dark:bg-gray-800">
      <div className="container flex items-center justify-between h-18 px-6 mx-auto text-purple-600 dark:text-purple-300">
        {/* <!-- Mobile hamburger --> */}
        <button
          className="p-1 mr-5 -ml-1 rounded-md lg:hidden focus:outline-none focus:shadow-outline-purple"
          onClick={toggleSidebar}
          aria-label="Menu"
        >
          <MenuIcon className="w-6 h-6" aria-hidden="true" />

        </button>

        <img src={Logo} width="120" height="120" alt='' />
        {/* <!-- Search input --> */}
        <div className="flex justify-center flex-1 lg:mr-32">
          <div className="relative w-full max-w-xl mr-6 focus-within:text-purple-500">
            <div className="absolute inset-y-0 flex items-center pl-2">
            </div>

          </div>
        </div>

      </div>
    </header>
  )
}

export default Header
