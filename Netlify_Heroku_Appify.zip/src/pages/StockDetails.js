import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import InfoCard from '../components/Cards/InfoCard'
import FbImage from '../assets/img/fb.png'
import GoogleImage from '../assets/img/google.png'
import AmazonImage from '../assets/img/amazon.png'

import PageTitle from '../components/Typography/PageTitle'
import { SearchIcon } from '../icons'
import response from '../utils/demo/tableData'
import {
    TableBody,
    TableContainer,
    Table,
    TableHeader,
    TableCell,
    TableRow,
    TableFooter,
    Badge,
    Input,
    Pagination,
    Select,
    Label,
    Button
} from '@windmill/react-ui'


function StockDetails() {
    const [page, setPage] = useState(1)
    const [data, setData] = useState([])

    // pagination setup
    const resultsPerPage = 10
    const totalResults = response.length

    // pagination change control
    function onPageChange(p) {
        setPage(p)
    }

    // on page change, load new sliced data
    // here you would make another server request for new data
    useEffect(() => {
        setData(response.slice((page - 1) * resultsPerPage, page * resultsPerPage))
    }, [page])

    return (
        <>


            {/* <!-- Cards --> */}
           
            <div className="grid gap-6 mb-8 md:grid-cols-2 xl:grid-cols-4 mt-8">
        <InfoCard title="GOOGLE" value="1515 USD">
          <img src={GoogleImage} width="96" height="65" alt=''/>
        </InfoCard>

        <InfoCard title="FB" value="266 USD">
          <img src={FbImage} width="96" height="65" alt=''/>
        </InfoCard>

        <InfoCard title="AMAZON" value="3116 USD">
          <img src={AmazonImage} width="96" height="65" alt=''/>
        </InfoCard>
      </div>
    
            <PageTitle>Stock Details Table</PageTitle>


            <div className="flex items-center justify-between  text-sm font-semibold text-purple-100 ">
                <div>
                    <div className="px-3 py-3">
                        <Label radio>
                            <span className="ml-0">Show</span>
                        </Label>
                        <Label className="ml-1" radio>
                            <Select className="mt-1">
                                <option>10</option>
                                <option>20</option>
                                <option>30</option>
                                <option>40</option>
                            </Select>
                        </Label>
                        <Label className="ml-0" radio>
                            <span className="ml-2">Entries</span>
                        </Label>
                    </div>
                </div>

                <span>
                    <div>
                        <div className="relative w-full max-w-xl mr-6 focus-within:text-purple-500">
                            <div className="absolute inset-y-0 flex items-center pl-2">
                                <SearchIcon className="w-4 h-4" aria-hidden="true" />
                            </div>
                            <Input
                                className="pl-8 text-gray-700"
                                placeholder="Search for Company Name"
                                aria-label="Search"
                            />
                        </div>
                    </div>
                </span>
            </div>


            <TableContainer>
                <Table>

                    <TableHeader>

                        <tr>
                            <TableCell>Company Name</TableCell>
                            <TableCell>Symbol</TableCell>
                            <TableCell>Market Cap</TableCell>
                            <TableCell> </TableCell>
                            <TableCell>Current Price</TableCell>
                        </tr>
                    </TableHeader>
                    <TableBody>
                        {data.map((user, i) => (
                            <TableRow key={i}>

                                <TableCell>
                                    <span className="text-sm">{user.companyName}</span>
                                </TableCell>
                                <TableCell>
                                    <Badge type={user.symbol}>{user.symbol}</Badge>
                                </TableCell>
                                <TableCell>
                                    <span className="text-sm">{user.market}</span>
                                </TableCell>
                                <TableCell>
                                    <div>
                                        <Button>
                                            Delete
                                        </Button>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <span className="text-sm">{user.price}</span>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                <TableFooter>
                    <Pagination
                        totalResults={totalResults}
                        resultsPerPage={resultsPerPage}
                        label="Table navigation"
                        onChange={onPageChange}
                    />
                </TableFooter>
                
            </TableContainer>
            <div class="md:flex md:items-center">
    <div class="md:w-2/3"></div>
    <div class="md:w-2/3">
      <Button class="shadow bg-purple-500 hover:bg-purple-400 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded" block tag={Link} to="/app">
        Back
      </Button>
    </div>
  </div>

         

           
        </>
    )
}

export default StockDetails
