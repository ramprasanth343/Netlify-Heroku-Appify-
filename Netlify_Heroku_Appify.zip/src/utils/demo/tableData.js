export default [
  {
    companyName: '141 Capital Inc',
    symbol:'. ONCP',
    market:'$145.5k',
    price: '$0.001 USD'
  },

  {
    companyName: 'Cardiytics',
    symbol:'. CDLX',
    market:'$1.88',
    price: '$66 USD'
  },

  {
    companyName: 'Brightcove Inc',
    symbol:'. BCOV',
    market:'$394M',
    price: '$10 USD'
  },

  {
    companyName: 'BigString Crop',
    symbol:'. BSGC',
    market:'$543k',
    price: '$0.003 USD'
  },
 
  {
    companyName: 'Akamai Technologies Inc',
    symbol:'. AKAM',
    market:'$145.4k',
    price: '$106 USD'
  },
 
 
]
